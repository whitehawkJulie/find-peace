import React from 'react';
import './App.css';
import NvcWizard from './components/NvcWizard';

function App() {
  return (
    <div className="app">
      <NvcWizard />
    </div>
  );
}

export default App;